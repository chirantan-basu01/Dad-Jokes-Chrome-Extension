# DAD JOKES CHROME EXTENSION

-   Everytime you click on the icon a new Dad Joke appears on the screen.

## ![Screenshot-1](images/1.png)

---

## ![Screenshot-2](images/2.png)

---

## ![Screenshot-3](images/3.png)

---
